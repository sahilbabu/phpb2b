<?php
/**
 *      [PHPB2B] Copyright (C) 2007-2099, Ualink Inc. All Rights Reserved.
 *      The contents of this file are subject to the License; 
 *		You may not use this file except in compliance with the License. 
 *
 *      @version $Revision: 2959 $
 */
define('PHPB2B_VERSION', '4.3');
define('PHPB2B_RELEASE', '20121009');
?>