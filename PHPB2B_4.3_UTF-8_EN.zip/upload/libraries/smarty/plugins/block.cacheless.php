<?php
/**
 * @copyright (C) 2007-2010  PHPB2B.COM. ALL RIGHTS RESERVED.
 * @link HTTP://WWW.PHPB2B.COM/
 * @license STRONGLY RECOMMENDED THAT USERS READ THE USE LICENSE, PLEASE.
 * @version $Rev: 42 $
 */
function smarty_block_cacheless($param, $content, &$smarty) {
   return $content;
}
?>