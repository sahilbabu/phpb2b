<?php
class Tradetype extends PbController {
	var $name = "Tradetype";
}
?>