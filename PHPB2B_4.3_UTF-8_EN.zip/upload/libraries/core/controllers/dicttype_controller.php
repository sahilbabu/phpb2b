<?php
class Dicttype extends PbController {
	var $name = "Dicttype";
}
?>