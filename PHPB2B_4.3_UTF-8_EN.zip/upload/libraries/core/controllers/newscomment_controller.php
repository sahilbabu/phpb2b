<?php
class Newscomment extends PbController {
	var $name = "Newscomment";
	
	function Newscomment()
	{
		
	}
}
?>