<?php
class Tradefield extends PbController {
	var $name = "Tradefield";
}
?>