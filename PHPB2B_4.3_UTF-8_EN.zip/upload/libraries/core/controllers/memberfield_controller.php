<?php
class Memberfield extends PbController {
	var $name = "Memberfield";
}
?>