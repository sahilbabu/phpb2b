<?php
class Ad extends PbController {
	var $name = "Ad";
}
?>