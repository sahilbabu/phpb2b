<?php
class Standardtype extends PbController {
	var $name = "Standardtype";
}
?>