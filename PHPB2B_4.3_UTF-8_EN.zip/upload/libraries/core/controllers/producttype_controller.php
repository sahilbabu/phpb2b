<?php
class Producttype extends PbController {
	var $name = "Producttype";
}
?>