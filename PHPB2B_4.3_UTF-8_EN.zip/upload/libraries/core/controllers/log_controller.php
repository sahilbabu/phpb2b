<?php
class Log extends PbController {
	var $name = "Log";
}
?>