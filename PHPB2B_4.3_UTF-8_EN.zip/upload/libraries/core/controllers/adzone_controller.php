<?php
class Adzone extends PbController {
	var $name = "Adzone";
}
?>