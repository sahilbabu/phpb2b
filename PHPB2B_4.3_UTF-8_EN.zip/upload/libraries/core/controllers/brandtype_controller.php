<?php
class Brandtype extends PbController {
	var $name = "Brandtype";
}
?>