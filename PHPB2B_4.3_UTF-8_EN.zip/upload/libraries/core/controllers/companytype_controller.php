<?php
class Companytype extends PbController {
	var $name = "Companytype";
}
?>