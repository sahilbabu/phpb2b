<?php
class Setting extends PbController {
	var $name = "Setting";

	function test(){
		echo "this is a model";
	}
}
?>