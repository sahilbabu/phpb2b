<?php
class Newstype extends PbController {
	var $name = "Newstype";
}
?>