<?php
class Membertype extends PbController {
	var $name = "Membertype";
}
?>