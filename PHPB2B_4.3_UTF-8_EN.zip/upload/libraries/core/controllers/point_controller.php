<?php
class Point extends PbController {
	var $name = "Point";
}
?>