<?php
class Expo extends PbController {
	var $name = "Expo";
}
?>