<?php
class Album extends PbController {
	var $name = "Album";
}
?>