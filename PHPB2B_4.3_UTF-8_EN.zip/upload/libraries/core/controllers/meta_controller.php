<?php
class Meta extends PbController {
	var $name = "Meta";
}
?>