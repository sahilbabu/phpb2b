<?php
class Companynews extends PbController {
	var $name = "Companynews";
}
?>