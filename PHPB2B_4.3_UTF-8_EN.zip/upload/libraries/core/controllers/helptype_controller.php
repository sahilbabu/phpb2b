<?php
class Helptype extends PbController {
	var $name = "Helptype";
}
?>