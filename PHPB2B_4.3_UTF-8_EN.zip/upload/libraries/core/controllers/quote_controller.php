<?php
class Quote extends PbController {
	var $name = "Quote";
}
?>