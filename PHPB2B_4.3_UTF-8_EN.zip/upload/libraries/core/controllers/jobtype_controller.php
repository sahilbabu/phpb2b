<?php
class Jobtype extends PbController {
	var $name = "Jobtype";
}
?>