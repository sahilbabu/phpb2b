<?php
class Productprice extends PbController {
	var $name = "Productprice";
}
?>