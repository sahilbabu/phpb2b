<?php
class Expotype extends PbController {
	var $name = "Expotype";
}
?>