<?php
class Adminfield extends PbController {
	var $name = "Adminfield";
}
?>