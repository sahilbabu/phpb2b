<?php
class Companyfield extends PbController {
	var $name = "Companyfield";
}
?>