<?php
class Spread extends PbController {
	var $name = "Spread";
}
?>