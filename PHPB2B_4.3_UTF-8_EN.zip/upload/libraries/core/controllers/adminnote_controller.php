<?php
class Adminnote extends PbController {
	var $name = "Adminnote";
}
?>