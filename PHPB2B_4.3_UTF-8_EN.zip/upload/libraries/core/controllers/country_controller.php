<?php
class Country extends PbController {
	var $name = "Country";
}
?>