<?php
class Order extends PbController {
	var $name = "Order";
}
?>