<?php
class Form extends PbController {
	var $name = "Form";
}
?>