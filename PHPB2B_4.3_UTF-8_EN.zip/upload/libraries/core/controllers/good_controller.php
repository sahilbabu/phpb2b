<?php
//multi name's, named : goodss
class Good extends PbController {
	var $name = "Good";
}
?>