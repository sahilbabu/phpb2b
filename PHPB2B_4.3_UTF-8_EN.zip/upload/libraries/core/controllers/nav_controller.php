<?php
class Nav extends PbController {
	var $name = "Nav";
}
?>