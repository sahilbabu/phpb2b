<?php
class Keyword extends PbController {
	var $name = "Keyword";
	var $keywords;
}