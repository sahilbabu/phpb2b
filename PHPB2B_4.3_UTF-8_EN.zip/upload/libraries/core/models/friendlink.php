<?php
class Friendlinks extends PbModel {
 	
 	var $name = "Friendlink";

 	function Friendlinks()
 	{
 		parent::__construct();
 	}
}
?>