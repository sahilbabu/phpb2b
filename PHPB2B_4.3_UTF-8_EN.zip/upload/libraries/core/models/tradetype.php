<?php
class Tradetypes extends PbModel {
 	var $name = "Tradetype";

 	function Tradetypes()
 	{
 		parent::__construct();
 	}
}
?>