<?php
class Membertypes extends PbModel {
 	var $name = "Membertype";
}
?>