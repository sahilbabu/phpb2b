<?php
class Jobs extends PbModel {
	var $name = "Job";

	function Jobs()
 	{
		parent::__construct();
 	}
}
?>