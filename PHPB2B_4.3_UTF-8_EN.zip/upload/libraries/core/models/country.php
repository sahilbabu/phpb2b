<?php
class Countries extends PbModel {
 	var $name = "Countries";

 	function Countries()
 	{
 		parent::__construct();
 	}
}
?>