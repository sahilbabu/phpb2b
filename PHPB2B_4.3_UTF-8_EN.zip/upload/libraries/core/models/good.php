<?php
class Goods extends PbModel {
 	var $name = "Goods";
}
?>