<?php
class Userpages extends PbModel {
	var $name = "Userpage";
}
?>