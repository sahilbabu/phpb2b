<?php
class Expotypes extends PbModel {
 	var $name = "Expotype";

 	function Expotypes()
 	{
 		parent::__construct();
 	}
}
?>