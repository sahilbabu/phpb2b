<?php
class Spreads extends PbModel {
 	
 	var $name = "Spread";

 	function Spreads()
 	{
 		parent::__construct();
 	}
}
?>