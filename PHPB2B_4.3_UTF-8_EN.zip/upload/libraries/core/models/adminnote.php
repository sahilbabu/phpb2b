<?php
class Adminnotes extends PbModel {
 	var $name = "Adminnote";

 	function Adminnotes()
 	{
 		parent::__construct();
 	}
}
?>