<?php
class Newscomments extends PbModel {
 	var $name = "Newscomment";

 	function Newscomments()
 	{
 		parent::__construct();
 	}
}
?>