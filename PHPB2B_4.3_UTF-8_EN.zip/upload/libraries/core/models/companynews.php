<?php
class Companynewses extends PbModel {
 	var $name = "Companynews";

 	function Companynewses()
 	{
 		parent::__construct();
 	}
}
?>