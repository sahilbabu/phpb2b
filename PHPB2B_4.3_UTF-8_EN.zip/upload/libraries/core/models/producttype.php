<?php
class Producttypes extends PbModel {
 	var $name = "Producttype";

 	function Producttypes()
 	{
 		parent::__construct();
 	}
}
?>