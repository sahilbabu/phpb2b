<?php
class Memberfields extends PbModel {
	var $name = "Memberfield";

	function Memberfields()
	{
		parent::__construct();
	}
}
?>