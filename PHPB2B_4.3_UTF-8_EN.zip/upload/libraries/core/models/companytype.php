<?php
class Companytypes extends PbModel {
 	var $name = "Companytype";
}
?>