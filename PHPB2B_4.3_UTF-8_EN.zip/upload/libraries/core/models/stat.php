<?php
class Stats extends PbModel {
 	var $name = "Stat";

 	function Stats()
 	{
		parent::__construct();
 	}
}
?>