<?php
$_CACHE['apps'] = array (
  8 => 
  array (
    'appid' => '8',
    'type' => 'OTHER',
    'name' => 'example',
    'url' => 'http://127.0.0.1/examples/passports',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  9 => 
  array (
    'appid' => '9',
    'type' => 'OTHER',
    'name' => 'test',
    'url' => 'http://127.0.0.1/test',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  7 => 
  array (
    'appid' => '7',
    'type' => 'OTHER',
    'name' => 'phpcms',
    'url' => 'http://127.0.0.1/phpcms',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  6 => 
  array (
    'appid' => '6',
    'type' => 'OTHER',
    'name' => 'phpb2b',
    'url' => 'http://127.0.0.1/phpb2b',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  4 => 
  array (
    'appid' => '4',
    'type' => 'ECMALL',
    'name' => 'ECMall',
    'url' => 'http://127.0.0.1/ecmall',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'utf-8',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  5 => 
  array (
    'appid' => '5',
    'type' => 'DISCUZ',
    'name' => 'discuz',
    'url' => 'http://127.0.0.1/dz',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://127.0.0.1/uc',
);
